
declare module 'lucide-react';
